
INSTRUCCIONES DE INSTALACIÓN:

1. Crea la base de datos PostgreSQL: auth_db y ejecuta el archivo database/schema.sql
2. Copia el archivo .env.example como .env y configura tus claves Clerk y PostgreSQL
3. Ejecuta el backend:
   cd backend
   npm install
   node app.js
4. Ejecuta el frontend:
   cd frontend
   npm install
   npm start
5. Abre el navegador en http://localhost:3000 y prueba el inicio de sesión y la ruta protegida.
