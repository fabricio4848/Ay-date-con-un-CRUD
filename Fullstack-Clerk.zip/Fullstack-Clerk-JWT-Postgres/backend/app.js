
// Backend en Node.js con Express y JWT - Español

const express = require('express');
const jwt = require('jsonwebtoken');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Ruta protegida de ejemplo
app.get('/api/protegida', (req, res) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).send('Token no proporcionado');

    jwt.verify(token.split(' ')[1], process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).send('Token no válido');
        res.json({ mensaje: 'Acceso concedido a la ruta protegida', usuario: user });
    });
});

app.listen(process.env.PORT, () => {
    console.log(`Servidor backend escuchando en el puerto ${process.env.PORT}`);
});
