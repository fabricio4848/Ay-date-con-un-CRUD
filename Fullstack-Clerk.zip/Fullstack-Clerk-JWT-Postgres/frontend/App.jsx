
// Frontend React usando ClerkProvider - Español

import { ClerkProvider, SignedIn, SignedOut, SignIn, UserButton } from '@clerk/clerk-react';
import React from 'react';
import axios from 'axios';

const frontendApi = process.env.REACT_APP_CLERK_PUBLISHABLE_KEY;

function App() {
    return (
        <ClerkProvider publishableKey={frontendApi}>
            <div>
                <h1>Inicio de sesión con Clerk y JWT</h1>
                <SignedOut>
                    <SignIn />
                </SignedOut>
                <SignedIn>
                    <UserButton />
                    <button onClick={async () => {
                        const token = localStorage.getItem('token');
                        const res = await axios.get('http://localhost:5000/api/protegida', {
                            headers: { Authorization: `Bearer ${token}` }
                        });
                        alert(res.data.mensaje);
                    }}>Acceder a Ruta Protegida</button>
                </SignedIn>
            </div>
        </ClerkProvider>
    );
}

export default App;
