const express = require('express');
const mongoose = require('mongoose');
const Tarea = require('./models/Tarea');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://127.0.0.1:27017/tareas_db');

app.get('/', async (req, res) => {
  const tareas = await Tarea.find();
  res.render('index', { tareas });
});

app.post('/add', async (req, res) => {
  await Tarea.create({ nombre: req.body.nombre });
  res.redirect('/');
});

app.post('/delete/:id', async (req, res) => {
  await Tarea.findByIdAndDelete(req.params.id);
  res.redirect('/');
});

app.listen(3000, () => console.log("Servidor http://localhost:3000"));