const mongoose = require('mongoose');
const tareaSchema = new mongoose.Schema({ nombre: String });
module.exports = mongoose.model('Tarea', tareaSchema);