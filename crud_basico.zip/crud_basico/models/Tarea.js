const mongoose = require('mongoose');
const Tarea = new mongoose.Schema({ texto: String });
module.exports = mongoose.model('Tarea', Tarea);